class StockData {
  late int xLabel;
  late double stockData;

  StockData(this.xLabel, this.stockData);
}
