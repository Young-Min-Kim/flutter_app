package com.example.flutter_json_stock_chart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
